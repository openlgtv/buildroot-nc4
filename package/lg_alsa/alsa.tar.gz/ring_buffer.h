#ifndef _RING_BUFFER_H_
#define _RING_BUFFER_H_

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "appfrwk_openapi.h"

typedef enum {
	RB_SUCCESS		= 0,
	RB_FAIL			= -1,
	RB_FULL			= -2,
	RB_OVERFLOW	= -3,
	RB_UNDERFLOW	= -4
} RB_STATUS_T;

typedef struct RING_BUFFER_FIXED_BLOCK {
	UINT16	nBuf;			/**< number of buffer 				*/
	UINT32	bufSize;			/**< buffer size in bytes			*/
	UINT16	readIndex;		/**< read index of buffer			*/
	UINT16	writeIndex;		/**< write index of buffer			*/
	UINT16	count;			/**< count that can be read space	*/
	UINT8	*pBuffer;		/**< pointer of buffer				*/
	UINT32	*pDataLength;	/**< legnth of data				*/
} RB_FIXED_BLOCK_T;

typedef struct RING_BUFFER_NONFIXED_BLOCK {
	UINT32	bufSize;			/**< buffer size in bytes			*/
	UINT32	readIndex;		/**< read index of buffer			*/
	UINT32	writeIndex;		/**< write index of buffer			*/
	UINT32	bufLevel;		/**< write index of buffer			*/
	UINT8	*pBuffer;		/**< pointer of buffer				*/
} RB_NONFIXED_BLOCK_T;

RB_STATUS_T RingBuffer_FixedBlock_Create(UINT16 bufNum, UINT32 bufSize, RB_FIXED_BLOCK_T **ppRbuf);
RB_STATUS_T RingBuffer_FixedBlock_Destroy(RB_FIXED_BLOCK_T *pRbuf);
RB_STATUS_T RingBuffer_FixedBlock_WriteData(RB_FIXED_BLOCK_T *pRbuf, UINT8 *data, UINT32 * length);
RB_STATUS_T RingBuffer_FixedBlock_ReadData(RB_FIXED_BLOCK_T *pRbuf, UINT8 *data, UINT32 * length);
void RingBuffer_FixedBlock_Reset(RB_FIXED_BLOCK_T *pRbuf);
UINT16 RingBuffer_FixedBlock_GetBufferLevel(RB_FIXED_BLOCK_T *pRbuf);

RB_STATUS_T RingBuffer_NonFixedBlock_Create(UINT32 bufSize, RB_NONFIXED_BLOCK_T **ppRbuf);
RB_STATUS_T RingBuffer_NonFixedBlock_Destroy(RB_NONFIXED_BLOCK_T *pRbuf);
RB_STATUS_T RingBuffer_NonFixedBlock_WriteData(RB_NONFIXED_BLOCK_T *pRbuf, UINT8 *data, UINT32 * length);
RB_STATUS_T RingBuffer_NonFixedBlock_ReadData(RB_NONFIXED_BLOCK_T *pRbuf, UINT8 *data, UINT32 * length);
void RingBuffer_NonFixedBlock_Reset(RB_NONFIXED_BLOCK_T *pRbuf);
UINT16 RingBuffer_NonFixedBlock_GetBufferLevel(RB_NONFIXED_BLOCK_T *pRbuf);

#endif	//_RING_BUFFER_H_

