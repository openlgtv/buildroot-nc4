#ifndef _MSG_QUEUE_H_
#define _MSG_QUEUE_H_

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#include "appfrwk_openapi.h"

#define ALIGN_4					(4 - 1)
#define QUE_WAIT_NONE			0
#define QUE_WAIT_FOREVER		-1

typedef enum {
	QUE_SUCCESS		= 0,
	QUE_FAIL			= -1,
	QUE_TIMEOUT		= -2,
	QUE_FULL			= -3,
	QUE_EMPTY			= -4
} QUE_STATUS_T;

typedef struct MSG_QUEUE {
	UINT32	q_size;
	UINT32	q_max;
	UINT32	q_head;
	UINT32	q_tail;
	UINT8 *	q_ptr;
	pthread_mutex_t mutex;
	pthread_cond_t  cond;	
} MSG_QUEUE_T;

QUE_STATUS_T MsgQueue_Create(MSG_QUEUE_T **  hQueue, UINT32 qmax, UINT32 qsize);
QUE_STATUS_T MsgQueue_Destroy(MSG_QUEUE_T *q);
QUE_STATUS_T MsgQueue_Send(MSG_QUEUE_T *q, UINT32 *msg);
QUE_STATUS_T MsgQueue_Wait(MSG_QUEUE_T *q, UINT32 *msg, UINT32 timeoutMsec);
QUE_STATUS_T MsgQueue_Flush(MSG_QUEUE_T *q);

#endif	//_MSG_QUEUE_H_
