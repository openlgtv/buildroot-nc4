
/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 */

#ifndef _QIC_XUCTRL_H_
#define _QIC_XUCTRL_H_

#ifdef __cplusplus
extern "C" {
#endif 

#include <sys/time.h>
#include "uvcvideo.h"
#include <linux/videodev2.h>


/* Flash Parameter */
#define FLASH_MAX_DATA_LEN		26


#define FLASH_PAGE_SIZE			0x100
#define FLASH_SECTOR_SIZE		0x1000
#define FLASH_MAX_SIZE			0x20000

#define FLASH_USB_ADDR			0x00000
#define FLASH_USB_MAX_SIZE		0x10000
#define FLASH_ISP_ADDR			0x10000
#define FLASH_ISP_MAX_SIZE		0x07000
#define FLASH_PARAM_ADDR		0x17000
#define FLASH_PARAM_MAX_SIZE	0x01000
#define FLASH_VERIFY_MAX_SIZE	FLASH_USB_MAX_SIZE

typedef enum {
	ENCODER_PROFILE_BASELINE	= 66,
	ENCODER_PROFILE_MAIN		= 77,
	ENCODER_PROFILE_EXTENDED	= 88,
	ENCODER_PROFILE_HIGH		= 100,
	ENCODER_PROFILE_HIGH_10		= 110,
	ENCODER_PROFILE_HIGH_422	= 122,
	ENCODER_PROFILE_HIGH_444	= 144,
	ENCODER_PROFILE_CAVLC_444	= 44
} EncoderProfile_t;

typedef enum {
	ENCODER_LEVEL_1				= 10,
	ENCODER_LEVEL_1B			= 19,
	ENCODER_LEVEL_1_1			= 11,
	ENCODER_LEVEL_1_2			= 12,
	ENCODER_LEVEL_1_3			= 13,
	ENCODER_LEVEL_2				= 20,
	ENCODER_LEVEL_2_1			= 21,
	ENCODER_LEVEL_2_2			= 22,
	ENCODER_LEVEL_3				= 30,
	ENCODER_LEVEL_3_1			= 31,
	ENCODER_LEVEL_3_2			= 32,
	ENCODER_LEVEL_4				= 40,
	ENCODER_LEVEL_4_1			= 41,
	ENCODER_LEVEL_4_2			= 42,
	ENCODER_LEVEL_5				= 50,
	ENCODER_LEVEL_5_1			= 51
} EncoderLevel_t;

typedef struct {
	unsigned int	uiBitrate;
	unsigned short	usWidth;
	unsigned short	usHeight;
	unsigned char	ucFramerate;
	unsigned char	ucSlicesize;
} EncoderParams_t;

typedef struct {
	unsigned int			uiTimeWindow;	// Not implement
	unsigned char			ucOverShoot;	// Not implement
	unsigned char			ucMinQP;
	unsigned char			ucMaxQP;
} EncoderQuality_t;

typedef struct {
	unsigned short			usWidth;
	unsigned short			usHeight;
	unsigned int			uiMinBitrate;
	unsigned int			uiMaxBitrate;
	unsigned char			ucMinFramerate;
	unsigned char			ucMaxFramerate;
} EncoderCapability_t;

typedef struct {
	char			szVID[5];
	char			szPID[5];
	char			szREV[5];
} FirmwareVersion_t;

typedef enum {
	MODE_FLASH_PROGRAM_PP	= 0x00,
	MODE_FLASH_PROGAME_AAI	= 0x01
} FlashProgramMode_t;

typedef enum {
	ENCRYPT_KEY_MODE_128	= 0x00,
	ENCRYPT_KEY_MODE_192	= 0x01,
	ENCRYPT_KEY_MODE_256	= 0x02
} EncyptKeyMode_t;

typedef enum {
	CALIBRATE_NORMAL		= 0x00,
	CALIBRATE_AE_DISABLE	= 0x01,
	CALIBRATE_AWB_DISABLE	= 0x02,
	CALIBRATE_AEAWB_DISABLE	= 0x03
} CalibratMode_t;

typedef enum {
	EFFECT_NONE				= 0x00,
	EFFECT_BLACK_WHITE		= 0x01,
	EFFECT_FALSE_COLOR		= 0x02,
	EFFECT_NEGATIVE			= 0x03,
	EFFECT_POSTERIZATION	= 0x04,
	EFFECT_SEPIA			= 0x05,
	EFFECT_SOLARIZATION1	= 0x06,
	EFFECT_SOLARIZATION2	= 0x07,
	EFFECT_EMBOSS1			= 0x08,
	EFFECT_EMBOSS2			= 0x09,
	EFFECT_SKETCH			= 0x0A
} SpecialEffect_t;

#define QIC_XU1_ENCODER_BITRATE			0x01
#define QIC_XU1_ENCODER_RESOLUTION		0x02
#define QIC_XU1_ENCODER_FRAMERATE		0x04
#define QIC_XU1_ENCODER_SLICESIZE		0x08
#define QIC_XU1_ENCODER_CONFIG_ALL		(QIC_XU1_ENCODER_BITRATE | QIC_XU1_ENCODER_FRAMERATE | \
						QIC_XU1_ENCODER_RESOLUTION | QIC_XU1_ENCODER_SLICESIZE)

#define QIC_XU1_QUALITY_TIMEWINDOW		0x01
#define QIC_XU1_QUALITY_OVERSHOOT		0x02
#define QIC_XU1_QUALITY_MINQP			0x04
#define QIC_XU1_QUALITY_MAXQP			0x08
#define QIC_XU1_QUALITY_ALL			(QIC_XU1_QUALITY_TIMEWINDOW | QIC_XU1_QUALITY_OVERSHOOT |	\
						QIC_XU1_QUALITY_MINQP | QIC_XU1_QUALITY_MAXQP)


int QicSetDeviceHandle (int vd);
int QicEncoderGetParams (EncoderParams_t *params);
int QicEncoderSetParams (EncoderParams_t *params, unsigned char flag);
int QicEncoderSetIFrame ();
int QicEncoderGetGOP (int *gop);
int QicEncoderSetGOP (int gop);
int QicEncoderGetQuality(EncoderQuality_t *quality);
int QicEncoderSetQuality(EncoderQuality_t *quality, unsigned char flag);
int QicEncoderGetNumberOfProfiles(int *num_profiles);
int QicEncoderGetProfile(int index, int *max_level, int *profile, int *constraint_flags);
int QicEncoderGetProfileAndLevel(int *level, int *profile, int *constraint_flags);
int QicEncoderSetProfileAndLevel(int level, int profile, int constraint_flags);

int QicEncoderGetNumberOfCapabilities( int *count);
int QicEncoderGetStreamCaps (int index, EncoderCapability_t *capability);

int QicMmioWrite (unsigned int addr, unsigned int value);
int QicMmioRead (unsigned int addr, unsigned int *value);

int QicFlashErase(void);
int QicFlashSectorErase (int addr);
int QicFlashCustom(char *data, int data_size);
int QicFlashWrite(int addr, char *data, int data_size);
int QicFlashWriteUSBIMG (int addr, char *data, int data_size);
int QicFlashRead(int addr, char *data, int data_size);
int QicFlashSetSpiConfig(unsigned int divider, FlashProgramMode_t mode);

int QicEncryptorSetKey(char *key, EncyptKeyMode_t key_mode);
int QicEncryptorGetKey(char *key, EncyptKeyMode_t key_mode);
int QicEncryptorSetConfig(int enable, EncyptKeyMode_t key_mode);

int QicXuSet (unsigned int ctrlId, unsigned char* pBuf, unsigned int size);
int QicXuGet (unsigned int ctrlId, unsigned char* pBuf, unsigned int size, unsigned int* sizeReturned);

int QicSetCalibrateMode(CalibratMode_t mode);
int QicSetSpecialEffect(SpecialEffect_t effect);
int QicSetWBComp(unsigned int r_gain, unsigned int g_gain, unsigned int b_gain);
int QicSetExpComp(unsigned int exp_time, unsigned short exp_gain);
int QicSetAeSpeed(unsigned short time_step, unsigned char gain_step);
int QicSetEncoderOption( unsigned char encoder_option);	// Not implement
int QicSetFlipMode(unsigned char flip_v, unsigned char flip_h);
int QicGetFlipMode(unsigned char *flip_v, unsigned char *flip_h);

int QicReset ();
int QicSetPll ();
int QicGetFirmwareVersion(FirmwareVersion_t *version);
int QicGetSerialNumber(char *serial_number, int data_len, int *bytes_returned);
int QicGetSvnVersion(unsigned int *version);
int QicSetLedMode(unsigned char mode);
int QicGetLedMode(unsigned char *mode);

void QicChangeFD(int fd);

#ifdef __cplusplus
}
#endif 


#endif
