#ifndef __DEVICELIST_H__
#define __DEVICELIST_H__

#include <sys/types.h>
#include "appfrwk_openapi_types.h"

void initLibDeviceList(void);
BOOLEAN getLibUsbMountedDevices(char *mounts, UINT32 bufsize);
void getLibDeviceList(char *result);
BOOLEAN setLibDevice(char *devname);
void getLibDeviceInfo(char *result);
long getLibDeviceFreeSpace(void);
	
#endif //__DEVICELIST_H__
