#ifndef _SHMEM_COMM_H_
#define _SHMEM_COMM_H_

typedef enum _SHMEM_STATUS_T
{
	SHMEM_COMM_OK			= 0x0,
	SHMEM_COMM_FAIL			= -1,
	SHMEM_COMM_OVERFLOW		= -2,
} SHMEM_STATUS_T;

typedef enum _SHMEM_MARK_T
{
	SHMEM_COMM_MARK_NORMAL		= 0x0,
	SHMEM_COMM_MARK_RESET		= 0x1,
	SHMEM_COMM_MARK_TERMINATE	= 0x2
} SHMEM_MARK_T;

#define SHMEM_NAME_SIZE 16
typedef struct _SHMEM_COMM_T
{
	char	name[SHMEM_NAME_SIZE];

	int		shmem_id;
	int		sema_id;

	/* shared memory overhead */
	int	*read_index;
	int	*write_index;
	int	*unit_size;
	int	*unit_num;
	SHMEM_MARK_T	*mark;

	unsigned int	*length_buf;
	unsigned char	*data_buf;
	unsigned int	total_size;
} SHMEM_COMM_T;

#define SHMEM_OVERHEAD_SIZE		(5*sizeof(int))
#define SHMEM_LENGTH_SIZE		sizeof(int)

#define SHMEM_COMM_NAME_MYVIDEO			"MyVideo"
#define SHMEM_COMM_NAME_MYVIDEO_EMP		"MyVideoEmp"

#define SHMEM_COMM_NAME_INCOMEVIDEO			"IncomeVideo"
#define SHMEM_COMM_NAME_INCOMEVIDEO_EMP		"IncomeVideoEmp"

#define SHMEM_COMM_NAME_INCOMEAUDIO			"IncomeAudio"
#define SHMEM_COMM_NAME_INCOMEAUDIO_EMP		"IncomeAudioEmp"

//FOR FFMPEG
#define SHMEM_DEFAULT_NAME					"RecStatus"
#define SHMEM_DEFAULT_NAME_EMP			"RecStatusEmp"



typedef enum _SHMEM_KEY_T
{
	SHMEM_COMM_KEY_MYVIDEO	= 6278,
	SHMEM_COMM_KEY_INCOMEVIDEO	= 6279,
	SHMEM_COMM_KEY_INCOMEAUDIO = 6280,
	//For FFMPEG
	DEFAULT_SHAREDMEM_KEY			= 1234,
	
} SHMEM_KEY_T;

extern SHMEM_STATUS_T shmem_comm_open(SHMEM_COMM_T **shmem_buffer2, const char *name, key_t shmem_key, int unit_size, int unit_num, int isWriter);
extern SHMEM_STATUS_T shmem_comm_read(SHMEM_COMM_T *shmem_buffer, unsigned char **buf, int *ret_size);
extern SHMEM_STATUS_T shmem_comm_write(SHMEM_COMM_T *shmem_buffer, unsigned char *buf, int size);
extern SHMEM_STATUS_T shmem_comm_set_status(SHMEM_COMM_T *shmem_buffer, SHMEM_MARK_T mark);
extern SHMEM_STATUS_T shmem_comm_get_status(SHMEM_COMM_T *shmem_buffer, SHMEM_MARK_T *mark);
extern int shmem_comm_get_count(SHMEM_COMM_T *shmem_buffer);
extern SHMEM_STATUS_T shmem_comm_close(SHMEM_COMM_T **shmem_buffer2);

#endif //_SHMEM_COMM_H_
