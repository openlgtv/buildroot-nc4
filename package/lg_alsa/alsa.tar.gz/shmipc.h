/*
 * Copyright (C) 2008-2010, Skype Limited
 *
 * All intellectual property rights, including but not limited to copyrights,
 * trademarks and patents, as well as know how and trade secrets contained
 * in, relating to, or arising from the internet telephony software of Skype
 * Limited (including its affiliates, "Skype"), including without limitation
 * this source code, Skype API and related material of such software
 * proprietary to Skype and/or its licensors ("IP Rights") are and shall
 * remain the exclusive property of Skype and/or its licensors. The recipient
 * hereby acknowledges and agrees that any unauthorized use of the IP Rights
 * is a violation of intellectual property laws.
 *
 * Skype reserves all rights and may take legal action against infringers of
 * IP Rights.
 *
 * The recipient agrees not to remove, obscure, make illegible or alter any
 * notices or indications of the IP Rights and/or Skype's rights and ownership
 * thereof.
 */

#ifndef __SHMIPC_H__
#define __SHMIPC_H__

#ifdef __cplusplus
extern "C" {
#endif

/* special defines for timeout */
#define SHMIPC_WAIT_FOREVER (-1)
#define SHMIPC_WAIT_NONE (0)

/* defined error codes */
#define SHMIPC_ERROR_NONE (0)
#define SHMIPC_ERROR_EINVAL (-1)
#define SHMIPC_ERROR_NOT_INITIALIZED (-2)
#define SHMIPC_ERROR_NOT_CONNECTED (-3)
#define SHMIPC_ERROR_TIMEOUT (-4)
#define SHMIPC_ERROR_SYSTEM (-5)

/* Definition for handle */
typedef void *SHMIPC_handle;

/* This structure defines packet of data. */
typedef struct SHMIPC_packet_t {
unsigned int	type; /* freely usable packet type definition */
unsigned int	length; /* packet length */
unsigned char	data[0];
} SHMIPC_packet;

/* All the timeout values defined in these functions here take a parameter in milliseconds
   or SHMIPC_WAIT_FOREVER or SHMIPC_WAIT_NONE */

/* Create and/or open channel: shm and sem are created if create is specified.
   Channel is opened. This call does not block */
SHMIPC_handle SHMIPC_open_channel(const char *name,unsigned int bufsize,int proj_id,int create_channel);
/* Close channel: Close the channel but leave the shm and sem intact if channel
   was opened with SHMIPC_open_channel not using flag create_channel, otherwise delete those */
void SHMIPC_close_channel(SHMIPC_handle channel);

/* Initialize the channel for sending data. */
int SHMIPC_initialize_sender(SHMIPC_handle channel);
/* Initialize the channel for receiving data. */
int SHMIPC_initialize_receiver(SHMIPC_handle channel);

/* put static information (==configuration) into channel, only server can do it before initialization */
int SHMIPC_put_config(SHMIPC_handle channel,void *data,unsigned int data_len);
/* get static information (==configuration) from channel. returns zero on failure */
void *SHMIPC_get_config(SHMIPC_handle channel);

/* Wait for the remote end to connect for time specified, or if timeout is zero, test if
   connection is alive */
int SHMIPC_wait_for_connection(SHMIPC_handle channel,int maxwait);

/* Send packet:
   the maxwait defines whether this call will block name time to wait for packet to be sent.
   The packet data can be in extbuffer or concatenated into packet (extbuffer null)
   returns zero when successfully sent packet, otherwise errorcode is returned */
int SHMIPC_send_packet(SHMIPC_handle channel,SHMIPC_packet *packet,const void *extbuffer,int maxwait);
/* Receive packet. maxwait defines how long the packet will be waited,
   if packet is null error code is provided in retval. Buffer is reused the next time
   SHMIPC_recv_packet is called */
SHMIPC_packet *SHMIPC_recv_packet(SHMIPC_handle channel,int maxwait,int *retval);

/* Disable locking (after this call, these functions are not thread-safe: only
   one thread can access one channels at time) */
void SHMIPC_disable_locking(SHMIPC_handle channel);

#ifdef __cplusplus
}
#endif

#endif
