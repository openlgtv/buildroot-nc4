#ifndef _CAMERA_API_H_
#define _CAMERA_API_H_

#include <pthread.h>
#include <asm/types.h>

#include "timing_stat.h"
#include "appfrwk_openapi.h"

#if 1
#define DEBUG_PRINT(fmt, args...) //printf("[Video Engine]%s " fmt, __FUNCTION__, ##args)
#define INFO_PRINT(fmt, args...) //printf("[Video Engine]%s " fmt, __FUNCTION__, ##args)
#define WARN_PRINT(fmt, args...) //printf("[Video Engine]%s " fmt, __FUNCTION__, ##args)
#define ERROR_PRINT(fmt, args...) //printf("[Video Engine]%s " fmt, __FUNCTION__, ##args)

#else
#define DEBUG_PRINT(fmt, args...)		TimingStat_DBGPrint(DEBUG_LEVEL_0, " \E[40m[Video Engine] " fmt, ##args)
#define INFO_PRINT(fmt, args...)		TimingStat_DBGPrint(DEBUG_LEVEL_1, " \E[40m[Video Engine] %s : " fmt, __FUNCTION__, ##args)
#define WARN_PRINT(fmt, args...)		TimingStat_DBGPrint(DEBUG_LEVEL_2, " \E[40m[Video Engine] \E[46m%s : " fmt "\E[40m", __FUNCTION__, ##args)
#define ERROR_PRINT(fmt, args...)		TimingStat_DBGPrint(DEBUG_LEVEL_3, " \E[40m[Video Engine] \E[41m%s : " fmt "\E[40m", __FUNCTION__, ##args)
#endif

#ifdef __cplusplus
extern "C" {
#endif


//FFMPEG
//===========================================================
#define SHMEM_OVERHEAD_SIZE				(2*sizeof(unsigned int))


#define	V4L2_SHM_KEY_VIDEO0				(6278)
#define	V4L2_SHM_KEY_VIDEO1				(6279)
#define	DEFAULT_V4L2_SHM_KEY			V4L2_SHM_KEY_VIDEO1

#define V4L2_SHM_CV_UNIT_SIZE			(128*1024)	// For compressed video such as H.264, MPEG2
#define V4L2_SHM_QVGA_UNIT_SIZE			(320*240*2)	// For fixed frame size video input
#define V4L2_SHM_VGA_UNIT_SIZE			(640*480*2)
#define V4L2_SHM_XGA_UNIT_SIZE			(1280*720*2)
#define	DEFAULT_V4L2_SHM_UNIT_SIZE		V4L2_SHM_CV_UNIT_SIZE
#define	DEFAULT_V4L2_SHM_UNIT_NUM		(16)

#define	ZERO_ASCII_CODE					(0x30)

#define	SHMEM_PREFIX					"shmem"
#define	SHMEM_DEFAULT_NAME				"RecStatus"


//#For AIT FIFO
#define	DEFAULT_MP4_VSRC				"/tmp/CameraFFMPEG.FIFO"

//#if (PLATFORM_TYPE == LG_PLATFORM )
//#define	DEFAULT_MP4_ASRC				"hw:0,0"
//#endif 
//#if (PLATFORM_TYPE == MTK_PLATFORM)
#define	DEFAULT_MP4_ASRC				"hw:1,0"
//#endif

#define	VIDEO_CODEC_NO					"nocodec"
#define	VIDEO_CODEC_COPY				"copy"
#define	VIDEO_CODEC_H264				"h264"
#define	VIDEO_CODEC_MPEG4				"mpeg4"
#define	VIDEO_CODEC_MPEG2				"mpeg2video"
#define	DEFAULT_VIDEO_CODEC				VIDEO_CODEC_H264

#define	DEFAULT_OUTAUDIO_CODEC			"aac"
#define	DEFAULT_OUTVIDEO_CODEC			VIDEO_CODEC_COPY

#define	DEFAULT_VSRC_FORMAT				"video4linux2"
#define	DEFAULT_ASRC_FORMAT				"alsa"
#define	DEFAULT_OUT_FORMAT				"mp4"

#define	DEFAULT_VSRC_RES				"1280x720"
#define	VSRC_FR_03						"3"
#define	VSRC_FR_04						"4"
#define	VSRC_FR_07						"7"
#define	VSRC_FR_11						"11"
#define	VSRC_FR_14						"14"
#define	VSRC_FR_15						"15"
#define	VSRC_FR_20						"20"
#define	VSRC_FR_22						"22"
#define	VSRC_FR_24						"24"
#define	VSRC_FR_30						"30"

#define	DEFAULT_ASRC_CHNUM				"2"

//#define	DEFAULT_PRGM_PATH				"/mnt/addon/contents/vcs/"
#define	DEFAULT_PRGM_PATH				"/usr/local/bin/"


#define DEFAULT_PRGM_NAME				"ffmpeg"

#define DEFAUL_PRGM_OPT1				"-loglevel"
#define DEFAUL_PRGM_OPT2				"verbose"
#define DEFAUL_PRGM_OPT3				"-y"
#define DEFAUL_PRGM_OPT4				"-timestamp"
#define DEFAUL_PRGM_OPT5				"00:00:00"

#define	DEFAULT_MP4_TAR					"/tmp/browser/camera/video.mp4"
#define	DEFAULT_JPEG_TAR				"/tmp/browser/camera/picture.jpg"


#define	DEFAULT_AUDIO_TAR				"/tmp/browser/camera/audio.mp3"

#define SIZE_10_MBYTES					10485760
#define SIZE_20_MBYTES					20971520
#define SIZE_50_MBYTES					52428800
#define SIZE_100_MBYTES					104857600
#define MAX_VIDEOREC_DURATTION			"120" //in seconds

#define	DEFAULT_MAX_OPTS				80
#define MAX_FILE_NAME_LENGTH_FFMPEG		512
#define MAX_SOURCE_NAME_LENGTH			25

union semunEx {
		int				val;
		struct semid_ds	*buf;
		unsigned short	*array;
		struct seminfo	*__buf;
};

typedef enum ShmemMode_T {
	SHMEM_DATA_MODE,
	SHMEM_MSG_MODE
} ShmemMode;

typedef struct ShmemBuffer_T {
	char	name[256];

	int		shmemId;
	int		semaId;

	unsigned int	key;

	unsigned char	*pBuffer;
	unsigned int	bufferSize;
	unsigned int	overheadSize;
} ShmemBuffer;

typedef struct RecStatus_T {
	unsigned int	timeSec;
	unsigned int	timeMilli;
	unsigned int	size;
	unsigned int	bitRate;
	unsigned int	frameNumber;
	unsigned int	fps;
	unsigned int	devInitDone;
	unsigned int	hoaDone;
	unsigned int	maxFileSize;
} RecStatus;

typedef enum e_cameraError {
    cameraError_OK 
    , cameraError_RESOURCE_NOT_INTIALIZED 
    , cameraError_RESOURCE_BUSY 
    , cameraError_RESOURCE_NOT_AVAILABLE 
    , cameraError_INVALID_STATUS 
    , cameraError_OPERATION_NOT_SUPPORTED 
    , cameraError_INVALID_ARGUMENT_VALUE 
    , cameraError_NOT_RECORDING
    , cameraError_UNKNOWN 
} cameraError;


typedef enum VideoType_T {
	VIDEO_YUYV,
	VIDEO_H264
} VideoType;


typedef enum {
	REC_VIDEO_AND_AUDIO	= 0,
	REC_VIDEO_ONLY		= 1,
	REC_AUDIO_ONLY		= 2
} REC_MEDIA_TYPE_T;

typedef enum
{
	RES1280X720		= 0,
	RES640x480		= 1,
	RES320x240		= 2,
	RES160X120		= 3
} REC_RESOLUTION_T;




//===========================================================
cameraError API_CAMERA_GetRecordStatus(RecStatus *pRecStatus);
void API_CAMERA_GetCameraVendorName(void);
cameraError API_CAMERA_StartPreview(void);
cameraError API_CAMERA_StopPreview(void);
cameraError API_CAMERA_TakePicture(void);
cameraError API_CAMERA_StartRecord(REC_MEDIA_TYPE_T RecOpt, unsigned int fileMax);
cameraError API_CAMERA_StopRecord(void);
cameraError API_CAMERA_SetCaptureResolution(int ResWidth, int ResHeight);






BOOLEAN Video_performance_debug(void);



cameraError API_CAMERA_Initialize(void);
cameraError API_CAMERA_Finalize(BOOLEAN forceFinalize);
BOOLEAN API_CAMERA_IsCameraConnected(void);
BOOLEAN API_CAMERA_StartIncomeVideo(UINT32 width, UINT32 height);
BOOLEAN API_CAMERA_StopIncomeVideo(void);
BOOLEAN API_CAMERA_StartOutgoVideo(UINT32 width, UINT32 height);
BOOLEAN API_CAMERA_StopOutgoVideo(void);
BOOLEAN API_CAMERA_IncomeVideoSendToBuf(UINT8 * buffer, UINT32 bufLen);
BOOLEAN API_CAMERA_OutgoVideoReceiveFromBuf(UINT8 * buffer, UINT32 * bufLen);
BOOLEAN API_CAMERA_SetBitrate(UINT32 bitrate);
BOOLEAN API_CAMERA_RequestKeyFrame(void);
BOOLEAN API_CAMERA_SetFrameRate(UINT8 framerate);

void API_CAMERA_OutgoVideoStreamWait(void);
void API_CAMERA_OutgoVideoStreamPost(void);
void API_CAMERA_SetIncomeVideoBitrateInfo(const char * info);
void API_CAMERA_SetOutgoVideoBitrateInfo(const char * info);
void API_CAMERA_CheckPacketLoss(UINT32 sequence);
char * API_CAMERA_RunVideoCmd(const char * cmd);

void _CAMERA_SetMyVideoProperty(void);

BOOLEAN API_VE_GetDeviceInfo(char* strName, char* devName, char* mixerName, unsigned int* pSamplingRate, int* pInputChannel);

BOOLEAN API_VE_StopMicRecording();
BOOLEAN API_VE_StartMicRecording();
BOOLEAN API_VE_CloseMic();
BOOLEAN API_VE_OpenMic();
BOOLEAN API_VE_OpenMixer();
BOOLEAN API_VE_CloseMixer();


BOOLEAN API_VE_GetMicData(char* pBuffer, int nBufferSize);


#ifdef __cplusplus
}
#endif

#endif	//_CAMERA_API_H_
