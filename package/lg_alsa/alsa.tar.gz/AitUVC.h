#ifndef AITUVC_H_INCLUDED
#define AITUVC_H_INCLUDED
#include <stdint.h>
#include <linux/videodev2.h>

#define SKYPE_H264_160X120 0x01
#define SKYPE_H264_320X240 0x02
#define SKYPE_H264_640X480 0x03
#define SKYPE_H264_960X720 0x04
#define SKYPE_H264_272X144 0x05
#define SKYPE_H264_368X208 0x06
#define SKYPE_H264_480X272 0x07
#define SKYPE_H264_624X352 0x08
#define SKYPE_H264_912X512 0x09
#define SKYPE_H264_1280X720 0x0A

//wIndex, Control Selector
#define EXU1_CS_SET_ISP				0x01
#define EXU1_CS_GET_ISP_RESULT		0x02
#define EXU1_CS_SET_FW_DATA			0x03
#define EXU1_CS_SET_MMP				0x04
    #define EXU1_MMP_LED_CONTROL        0x0E
#define EXU1_CS_GET_MMP_RESULT		0x05
//#define EXU1_CS_SET_ISP_EX			0x06
#define EXU1_CS_GET_ISP_EX_RESULT	0x07
#define EXU1_CS_READ_MMP_MEM		0x08
#define EXU1_CS_WRITE_MMP_MEM		0x09
//#define EXU1_CS_GET_CHIP_INFO		0x0A
#define EXU1_CS_GET_DATA_32         0x0B
#define EXU1_CS_GET_DATA	        0x0B        //same EXU1_CS_GET_DATA_32 but size change to 30 bytes
    #define EXU1_CS_GET_DATA_LEN    32//30      //XU data size
#define EXU_CS_SET_MMP_CMD16        0x0E
#define EXU1_CS_SET_MMP_CMD16       0x0E
    #define EXU1_MMP16_SET_AUDIO_MODE   0x05        //Sub command ID for MMP16
        #define AUDIO_MODE_RESERVED_0       0x00
        #define AUDIO_MODE_RESERVED_1       0x01
        #define AUDIO_MODE_RESERVED_2       0x02
        #define AUDIO_MODE_RESERVED_3       0x03
        #define AUDIO_MODE_RESERVED_4       0x04
        #define AUDIO_MODE_RAW_AUDIO        0x05    //Raw Audio Mode
        #define AUDIO_MODE_NORMAL           0x06
#define EXU_CS_GET_MMP_RESULT16     0x0F
#define EXU1_CS_GET_MMP_RESULT16    0x0F

typedef void* SkypeXUHandle;

//returns
#define AIT_XU_OK                   0x00000000
#define AIT_H264_DUMMY_FRAME        0x00000001
#define AIT_H264_IFRAME             0x00000002
#define AIT_H264_PFRAME             0x00000003

#define AIT_XU_ERROR                0x80000000
#define AIT_XU_OUT_OF_RANGE         0x80000001

//XU command directon from HOST side
#define AIT_XU_CMD_IN  0
#define AIT_XU_CMD_OUT 1

#define PTZ_PAN_STEP    0xE10
#define PTZ_TILT_STEP   0xE10
#define PTZ_ZOOM_STEP   0x01
typedef void* AitXUHandle;

//H264 parser, it extracts a frame of H264 data from AIT MJPG+H264 payload, to separated buffer
//[IN] const uint8_t* src_buf: The data from device output
//[IN] uint32_t src_buf_len: The data length of src_buf
//[IN] uint8_t* h264_buf: The H264 data buffer allocated by caller
//[IN] uint32_t h264_buf_len:  The buffer length of h264_buf
//[OUT] uint32_t *h264_buf_used: Return the actual h264 data length to caller
//[RETURN] AIT_H264_FRAME : No error
//         AIT_H264_DUMMY_FRAME : data incorrect
int AitH264Demuxer_MJPG_H264(const uint8_t* src_buf, uint32_t src_buf_len, uint8_t* h264_buf, uint32_t h264_buf_len, uint32_t *h264_buf_used);

//Initialize Ait extension unit library
//[IN] char *dev_name: Device path
//[RETURN]  A handle of library
AitXUHandle AitXU_Init(char *dev_name);

//Release Ait extension unit library
//[IN] AitXUHandle* handle: Address of handle
void AitXU_Release(AitXUHandle* handle);

//Set H264 stream bitrate
//parameters:
//[IN] AitXUHandle handle:
//[IN] int birrate: set H264 bitrate in kbps
int AitXU_SetBitrate(AitXUHandle handle,int bitrate);

//Set H264 frame rate
//parameters:
//[IN] AitXUHandle handle:
//[IN] uint8_t fps: set H264 frame rate in frame per second.
int AitXU_SetFrameRate(AitXUHandle handle,uint8_t fps);

//Set H264 encoding resolution
int AitXU_SetEncRes(AitXUHandle handle,uint8_t resolution);

//Force device send an H264 IDR frame to H264 stream immediately.
//parameters:
//[IN] AitXUHandle handle:
int AitXU_SetIFrame(AitXUHandle handle);

//Set IDR frame period
//parameters:
//[IN] AitXUHandle handle:
//[IN] unsigned int val: Set the period of I frame in sequences of P frame
//                       for example: val=30 it means device will generate a I frame per 30 P frames
int AitXU_SetPFrameCount(AitXUHandle handle,unsigned int val);

//UVC
//UVC Processing Unit control
//[IN] AitXUHandle handle:
//[IN/OUT] __s32 *val:  Control value write to device or read from device
//[IN]__u32 id:         Control ID
//                      V4L2_CID_BRIGHTNESS	integer	Picture brightness, or more precisely, the black level.
//                      V4L2_CID_CONTRAST	integer	Picture contrast or luma gain.
//                      V4L2_CID_SATURATION	integer	Picture color saturation or chroma gain.
//                      V4L2_CID_HUE	    integer	Hue or color balance.
//                      V4L2_CID_GAMMA
//                      V4L2_CID_BLACK_LEVEL
//                      V4L2_CID_AUTO_WHITE_BALANCE
//                      V4L2_CID_WHITE_BALANCE_TEMPERATURE
//                      V4L2_CID_POWER_LINE_FREQUENCY
//                      V4L2_CID_GAIN
//                      V4L2_CID_EXPOSURE_ABSOLUTE
//                      V4L2_CID_EXPOSURE_AUTO
//[IN] unsigned char direction: Command direction,
//                      AIT_XU_CMD_IN: Get value to host
//                      AIT_XU_CMD_OUT: Set value to device
int AitUVC_PUControl(AitXUHandle handle,__s32 *val,__u32 id,unsigned char direction); //processing unit control
int AitUVC_PUQuery(AitXUHandle handle,__u32 id,__s32 *max,__s32 *min,__s32 *step);


//Standard UVC Camera unit control
//[IN] AitXUHandle handle:
//[IN] __s64 *val:  Control value, range as below
//                  ZOOM: 0 - 10 , step 1
//                  PAN: -36000 - 36000, step 3600
//                  TILT: -36000 - 36000, step 3600
//[IN/OUT] __s32 id:
//                      V4L2_CID_PAN_ABSOLUTE
//                      V4L2_CID_TILT_ABSOLUTE
//                      V4L2_CID_ZOOM_ABSOLUTE
//[IN] unsigned char direction: Command direction,
//                      AIT_XU_CMD_IN: Get value to host
//                      AIT_XU_CMD_OUT: Set value to device
int AitUVC_CameraCmd(AitXUHandle handle,__s64 *val,__u32 id,unsigned char direction);


//Update device firmware to flash
//[IN] AitXUHandle handle:
//[IN] unsigned char* fw_data: The data buffer of firmware binary
//[IN] unsigned int len: Data length if fw_data
int AitXU_UpdateFW(AitXUHandle handle,unsigned char* fw_data,unsigned int len);

//Update device firmware to flash
//[IN] AitXUHandle handle:
//[IN] char* fwBuildDay: 12 bytes buffer to receives firmware build day in ASCII code
int AitXU_GetFWBuildDate(AitXUHandle handle,char *fwBuildDay);

//Update device firmware to flash
//[IN] AitXUHandle handle:
//[IN] char* fwBuildDay: 6 bytes buffer to receives firmware version, format as below
//                       Major : fwVer[1] + fwVer[0]<<8
//                       Minor : fwVer[3] + fwVer[2]<<8
//                       Build : fwVer[5] + fwVer[4]<<8
int AitXU_GetFWVersion(AitXUHandle handle,unsigned char *fwVer);

//Send a UVC Extension Command to device
//[IN] AitXUHandle handle:
//[IN][OUT] unsigned char* cmd: command buffer, the buffer length depend on param4 command lens
//[IN] unsigned short cs: Control Selector of UVC Extension Unit
//[IN] unsigned char len: Command lens
//[IN] unsigned char direction: command data direction
//                              AIT_XU_CMD_IN: device to host
//                              AIT_XU_CMD_OUT: host to device
int AitXU_XuCmd(AitXUHandle handle,unsigned char* cmd,unsigned short cs,unsigned char len, unsigned char direction);
#endif // AITUVC_H_INCLUDED
