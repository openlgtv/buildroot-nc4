#ifndef _TIMING_STAT_H_
#define _TIMING_STAT_H_

#include "appfrwk_openapi.h"

typedef struct TIMING_STAT {
	UINT32		frmNum;
	UINT64		lastFrmTimestamp;
	UINT64		lastFrmTime;
	UINT64		frmTimeSum;
	UINT32		calcInterval;
	UINT64		startTime;
	BOOLEAN		bIntervalStart;
} TIMING_STAT_T;

#ifdef __cplusplus
extern "C" {
#endif

UINT64 TimingStat_GetTimeUs(void);
//SINT32 TimingStat_DBGPrint(DEBUG_LEVEL_T level, const char *format , ... );
BOOLEAN TimingStat_Create(UINT32 interval, TIMING_STAT_T **ppTStat);
BOOLEAN TimingStat_Destroy(TIMING_STAT_T *pTStat);
BOOLEAN TimingStat_IsValid(TIMING_STAT_T *pTStat);
void TimingStat_Reset(TIMING_STAT_T *pTStat);
void TimingStat_Update(TIMING_STAT_T *pTStat);
CHAR * TimingStat_GetStatStr(TIMING_STAT_T *pTStat);

#ifdef __cplusplus
}
#endif

#endif	//_TIMING_STAT_H_

