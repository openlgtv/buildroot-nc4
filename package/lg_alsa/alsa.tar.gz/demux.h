/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 */

#ifndef _QICDEMUX_H_
#define _QICDEMUX_H_

#ifdef __cplusplus
extern "C" {
#endif 

#define TS_GET_ERR_INDI(x)          (((*(x+1)) & 0x80) >> 7)
#define TS_GET_UNIT_START(x)        (((*(x+1)) & 0x40) >> 6)
#define TS_GET_PID(x)               ((((*(x+1)) & 0x1F) << 8) + (*(x+2)))
#define TS_GET_SCRAMBLE(x)          (((*(x+3)) & 0xC0) >> 6)
#define TS_GET_ADAPT_CTRL(x)        (((*(x+3)) & 0x30) >> 4)
#define TS_GET_CONTI_CNT(x)         ((*(x+3)) & (0xf))
#define TS_OK                       0
#define TS_ERR                      -1
#define PES_OK                      0
#define PES_ERR                     -1
#define PID							0x11
#define TS_PKT_SIZE					188
#define TS_PKT_HDR_LEN				(4)
#define PES_PKT_HDR_LEN				(9)
#define MAXBUFFERCOUNT				5
#define MAXFRAMESIZE				128*1024
typedef struct
{
	unsigned char data[MAXFRAMESIZE];		//store the raw H.264 bitstream
	int length;						//indicate the data length
	unsigned long  timestamp;
}H264DATAFORMAT;
typedef struct
{
	int length;						//indicate the data length
	unsigned long  timestamp;
}H264DATAFORMAT_IN;;
typedef struct
{
	int ts_counter;	
	int ts_payload_len;
	int pes_payload_len;
	int ts_adapt_len;
	int wait_start;
	int pid;
	int unit_start;
	int pos;
	int byteused;
	unsigned long timestamp;
	unsigned char data[MAXFRAMESIZE];
}Packet_Source;
typedef struct
{
	H264DATAFORMAT_IN  frame;
	int frame_count;		
	int frame_pre_send;
	int bad_count;
	int drop_count;
	int wait_i;
	int not_complete;
	int adopt_recover;
	int maxbuffer;
	Packet_Source usb;	
}info;

//typedef int(*fun_parse) (info* data, unsigned char *src, int size, H264DATAFORMAT **out) ;
//typedef void(*fun_init)(info *data);
typedef struct
{
	info data;
//	fun_init	init;
//	fun_parse parse;	
}demux;
void demux_init(info *data);
void demux_adopt_recover(info *data);
void demux_set_maxbuffer(info *data, int size);
int demux_parse(info *data,unsigned char *src , int size , H264DATAFORMAT **out);

#ifdef __cplusplus
}
#endif 

#endif

