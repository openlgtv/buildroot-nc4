
#include "AitUVC.h"

#define ST_YUY2	41
#define ST_NV12	42
#define ST_H264	43
#define ST_MJPG	44
#define ST_GRAY 45

//#define V4L2_CID_ZOOM_ABSOLUTE 10094861

#define SKYPE_H264_160X120 0x01
#define SKYPE_H264_320X240 0x02
#define SKYPE_H264_640X480 0x03
#define SKYPE_H264_960X720 0x04
#define SKYPE_H264_272X144 0x05
#define SKYPE_H264_368X208 0x06
#define SKYPE_H264_480X272 0x07
#define SKYPE_H264_624X352 0x08
#define SKYPE_H264_912X512 0x09
#define SKYPE_H264_1280X720 0x0A

#ifdef __cplusplus
extern "C" {
#endif

int ait_camera_initialize(char *dev_name, int width, int height, int bitrate, int framerate);
void ait_camera_callback_register_H264(void (*func)(int fd, unsigned int data_length, unsigned char *data, unsigned int timestamp));
//void ait_camera_callback_register_YUY2(void (*func)(int fd, unsigned int data_length, unsigned char *data, unsigned int timestamp));
int ait_camera_start_capture();
void *ait_camera_loop_thread(void *arg);
int ait_camera_stop_capture();
int ait_camera_finalize();

int ait_camera_set_led(int ledOnOff);
int ait_camera_get_firmware_version(char * ret);
int ait_camera_update_firmware(char *dir);

int ait_camera_set_gop_length(int gop_length);
int ait_camera_set_bitrate(int bitrate_bps);
int ait_camera_set_framerate(int framerate);
int ait_camera_set_resolution(int width, int height);
int ait_camera_set_Iframe();

int ait_camera_set_zoom(int value);
int ait_camera_set_pan_tilt(int pan, int tilt);

int ait_camera_set_brightness(int value);
int ait_camera_set_contrast(int value);
int ait_camera_set_saturation(int value);
int ait_camera_set_sharpness(int value);
int ait_camera_set_hue(int value);
int ait_camera_set_gamma(int value);
int ait_camera_set_gain(int value);
int ait_camera_set_BL(int value);
int ait_camera_set_AWB(int value);
int ait_camera_set_WBT(int value);
int ait_camera_set_PLF(int value);
int ait_camera_set_gain(int value);
int ait_camera_set_exposure_absolute(int value);
int ait_camera_set_exposure_auto(int value);

#ifdef __cplusplus
}
#endif
