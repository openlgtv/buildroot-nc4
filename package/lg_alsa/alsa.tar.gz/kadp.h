
typedef enum
{
	LX_GFX_SURFACE_TYPE_NONE				= 0,	/**< -- virtual surface type (constant color) */
	LX_GFX_SURFACE_TYPE_COLOR				= 0,	/**< -- virtual surface type (constant color) */
	LX_GFX_SURFACE_TYPE_MEM_BUFFER			= 1,	/**< -- surface buffer is allocated in gfx engine */
	LX_GFX_SURFACE_TYPE_EXTERN_MEM_BUFFER	= 2,	/**< -- surface buffer is preallocated */
}
LX_GFX_SURFACE_TYPE_T;


typedef enum
{
	LX_GFX_PIXEL_FORMAT_INDEX_0		= 0,					/**< virtual pixel format indicating the constant color */

	LX_GFX_PIXEL_FORMAT_INDEX_1 	= 0x1,					/**< 1bpp indexed color */
	LX_GFX_PIXEL_FORMAT_INDEX_2 	= 0x2,					/**< 2bpp indexed color */
	LX_GFX_PIXEL_FORMAT_INDEX_4 	= 0x3,					/**< 4bpp indexed color */
	LX_GFX_PIXEL_FORMAT_INDEX_8 	= 0x4,					/**< 8bpp indexed color */

	LX_GFX_PIXEL_FORMAT_ALPHA_8 	= 0x5,					/**< 8bpp, only alpha plane ?? */

	LX_GFX_PIXEL_FORMAT_Y8__Cb8_444__Cr8_444	= 0x6,		/**< 8bpp, unpacked (Y8 / Cb8 for 444 / Cr8 for 444 )*/
	LX_GFX_PIXEL_FORMAT_Cb8_422__Cr8_422 		= 0x7,		/**< 8bpp, unpacked (Cb8 for 422 / Cr8 for 422 )	*/
	LX_GFX_PIXEL_FORMAT_Cb8_420__Cr8_420 		= 0x8,		/**< 8bpp, unpacked (Cb8 for 420 / Cr8 for 420 ) 	*/

	LX_GFX_PIXEL_FORMAT_YCbCr655		= 0x9,				/**< 16bpp, Y6 Cb5 Cr5 */
	LX_GFX_PIXEL_FORMAT_AYCbCr2644 		= 0xa,				/**< 16bpp, A2 Y6 Cb4 Cr4 */
	LX_GFX_PIXEL_FORMAT_AYCbCr4633 		= 0xb,				/**< 16bpp, A4 Y6 Cb3 Cr3 */
	LX_GFX_PIXEL_FORMAT_AYCbCr6433 		= 0xc,				/**< 16bpp, A6 Y4 Cb3 Cr3 */

	LX_GFX_PIXEL_FORMAT_CbCr_420 		= 0xd,				/**< 16bpp, CbCr interleaved */
	LX_GFX_PIXEL_FORMAT_CbCr_422 		= 0x1d,				/**< 16bpp, CbCr interleaved */
	LX_GFX_PIXEL_FORMAT_CbCr_444 		= 0x1f,				/**< 16bpp, CbCr interleaved */

	LX_GFX_PIXEL_FORMAT_RGB565 			= 0x19,				/**< 16bpp, R5 G6 B 5 */
	LX_GFX_PIXEL_FORMAT_ARGB1555		= 0x1a,				/**< 16bpp, A1 R5 G5 B5 */
	LX_GFX_PIXEL_FORMAT_ARGB4444 		= 0x1b,				/**< 16bpp, A4 R4 G4 B4 */
	LX_GFX_PIXEL_FORMAT_ARGB6343 		= 0x1c,				/**< 16bpp, A6 R3 G4 B3 */

	LX_GFX_PIXEL_FORMAT_AYCbCr8888	 	= 0xe,				/**< 32bpp, A8 Y8 Cb8 Cr8 */
	LX_GFX_PIXEL_FORMAT_Y0Cb0Y1Cr0_422	= 0xf,				/**< 32bpp, YCbCr-422 interleaved (YUYV) */
	LX_GFX_PIXEL_FORMAT_ARGB8888 		= 0x1e,				/**< 32bpp, A8 R8 G8 B8 */
}
LX_GFX_PIXEL_FORMAT_T;

typedef struct
{
	void*					phys_addr;		/**< physical address of the surface */
	UINT32					offset;			/**< memory offset information from the surface base address */
	UINT32					length;			/**< allocated byte size of the surface (total buffer length) */
}
LX_GFX_PHYS_MEM_INFO_T;


typedef struct
{
	UINT32						surface_fd;		/**< surface fd */
	LX_GFX_SURFACE_TYPE_T		surface_type;	/**< surface type */
	UINT16						width;			/**< surface width */
	UINT16						height;			/**< surface height */
	UINT32						stride;			/**< surface stride */
	LX_GFX_PIXEL_FORMAT_T		pixel_format;	/**< pixel format */

	LX_GFX_PHYS_MEM_INFO_T		phys_mem_info;	/**< surface physical information */
	void*						mmap_ptr;		/**< valid only for LX_GFX_SURFACE_TYPE_MEM_BUFFER */

	UINT32						appdata[2];		/**< application data */
}
LX_GFX_SURFACE_T, *LX_GFX_SURFACE_HANDLE_T;


typedef struct
{
	void*						handle;			/**< internal use only */

	UINT32						length;			/**< buffer length */
	UINT32						phys_addr;		/**< physical address of buffer for DMA */
	void*						mmap_ptr;		/**< memory mapped address. valid for calling only current process */
}
LX_GFX_IMAGE_BUFFER_T;

typedef struct
{
#define	LX_GFX_YUV_FMT_420_I	0	/* interleaved h_sub=2, v_sub=2 */
#define	LX_GFX_YUV_FMT_422_I	1	/* interleaved h_sub=2, v_sub=1 */
#define	LX_GFX_YUV_FMT_444_I	2	/* interleaved h_sub=1, v_sub=1 */
#define	LX_GFX_YUV_FMT_400		3	/* y only */

#define	LX_GFX_YUV_FMT_420		0	/* interleaved h_sub=2, v_sub=2 */
#define	LX_GFX_YUV_FMT_422		1	/* interleaved h_sub=2, v_sub=1 */
#define	LX_GFX_YUV_FMT_444		2	/* interleaved h_sub=1, v_sub=1 */

	UINT32		yuv_fmt;		/* yuv format */

	UINT32		stride_y;		/* stride is feeded by jpeg decoder */
	UINT32		stride_c;		/* stride is feeded by jpeg decoder */

	UINT32		width;			/* width  is feeded by jpeg decoder */
	UINT32		height;			/* height is feeded by jpeg decoder */

	UINT32		phys_addr_y;	/* physical address for Y  */
	UINT32		phys_addr_cb;	/* physical address for Cb */
	UINT32		phys_addr_cr;	/* physical address for Cr */
}
LX_GFX_YUV_IMAGE_T;

typedef enum
{
	LX_FBDEV_ID_OSD0	= 0,	/* general purpose OSD */
	LX_FBDEV_ID_OSD1	= 1,	/* general purpose OSD */
	LX_FBDEV_ID_OSD2	= 2,	/* general purpose OSD */
	LX_FBDEV_ID_OSD3	= 3,	/* cursor only */
	LX_FBDEV_ID_CSR0	= 3,	/* cursor only */

	LX_FBDEV_ID_MAX,
}
LX_FBDEV_ID_T;

typedef struct
{
	UINT16		x;			///< x ( offset )
	UINT16		y;			///< y ( offset )
	UINT16		w;			///< width
	UINT16		h;			///< height
}
LX_RECTANGLE_T /* long form */, LX_RECT_T /* short form */ ;

typedef SINT16				LX_GFX_DIMENSION_T;
typedef SINT16				LX_GFX_POSITION_T;

typedef struct
{
	/** FB device screen info
	 *  xres, yres, xres_virtual, yres_virtual, bits_per_pixel can be changed.
	 *
	 */
	struct
	{
		UINT16					xres;
		UINT16					yres;
		UINT16					xres_virtual;
		UINT16					yres_virtual;
		UINT32					bits_per_pixel;
	}
	fbinfo;

	/** input window information
	 *	valid range is from 0 to area of input canvas
	 */
	LX_RECT_T				input_win;

	/** output window information
	 *	value range is from 0 to 1920x1080 sized display area.
	 *  [note] output_win should be larger than input_win.
	 */
	LX_RECT_T				output_win;

	UINT32					color_key_enable:1,		///< enable/disable color key.

	/** enable/disable global alpha
	 *
	 * When enabled, device driver should use global_alpha to control layer trasparency.
	 */
							global_alpha_enable:1,
							:30;

	UINT32					global_alpha;			///< layer alpha when global_alpha_enable is TRUE
													//	 ( 0: full transparent ~ 0xff: opaque - default )\n

	UINT32					color_key;				///< color key when color_key_enable is TRUE.\n
													///	 <b> 2010/02/23 </b>
													///	 L8 replaces alpha field of each pixel with global_alpha
													///	 when global_alpha_enable is TRUE.
													///	 So you cannot apply color_key exactly when both global_alpha
													///	 and color_key are enabled since alpha field is modified
													///	 by system.
													///	 So L8 device driver ignores alpha field of color_key data
													///	 when global alpha is enabled. ( This is a simple wrapround )
}
LX_FBDEV_CONFIG_T;



extern void	KADP_InitSystem		( void );
extern void	KADP_ShutdownSystem ( void );

int	KADP_GFX_Open 				( void );
int	KADP_GFX_Close				( void );

int	KADP_FBDEV_Open				( LX_FBDEV_ID_T	id );
int	KADP_FBDEV_Close			( LX_FBDEV_ID_T id );
int	KADP_FBDEV_SetVisible		( LX_FBDEV_ID_T id, BOOLEAN fVisible );
int	KADP_FBDEV_GetSurface		( LX_FBDEV_ID_T id, int	screenIdx, LX_GFX_SURFACE_T* pSurface );


int	KADP_GFX_CreateImageBuffer	( LX_GFX_IMAGE_BUFFER_T**	phImgBuf, UINT32 length );
int	KADP_GFX_DestroyImageBuffer	( LX_GFX_IMAGE_BUFFER_T*	hImgBuf );

LX_GFX_SURFACE_T*	KADP_GFX_SimpleCreateSurface( 	LX_GFX_PIXEL_FORMAT_T 	pixel_format,
													LX_GFX_DIMENSION_T 		width,
													LX_GFX_DIMENSION_T 		height );



int	KADP_FBDEV_GetConfiguration ( LX_FBDEV_ID_T id, LX_FBDEV_CONFIG_T* pCfg );
int	KADP_FBDEV_SetConfiguration ( LX_FBDEV_ID_T id, LX_FBDEV_CONFIG_T* pCfg );


int	KADP_FBDEV_FlipScreenEx	( LX_FBDEV_ID_T	id, BOOLEAN fWaitSync );


int KADP_GFX_ConvertYUV2ARGBEx	( UINT32				id,
								  LX_GFX_YUV_IMAGE_T*	yuv_image,
								  LX_GFX_SURFACE_T*		surface,
								  BOOLEAN				b_coc_enable );



int KADP_GFX_SimpleBlit		(	UINT32 	id,
								LX_GFX_SURFACE_HANDLE_T hSrcSurface,
								LX_RECT_T*              pSrcRect,
								LX_GFX_SURFACE_HANDLE_T hDstSurface,
								LX_GFX_POSITION_T       dstX,
								LX_GFX_POSITION_T       dstY );
#if 0
int KADP_GFX_SimpleStretchBlit	(	UINT32 id,
								LX_GFX_SURFACE_HANDLE_T 	hSrcSurface,
								LX_RECT_T*					pSrcRect,
								LX_GFX_SURFACE_HANDLE_T 	hDstSurface,
								LX_RECT_T*					pDstRect,
								LX_GFX_SW_SCALE_SETTINGS_T* pSettings );
#endif

