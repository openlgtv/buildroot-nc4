#include <ae/stagecraft/IStagecraft.h>
#include "appfrwk_openapi.h"

#define BILLING_CHARGENO_MAX_SIZE 16
#define BILLING_RESPONSEENCDATA_MAX_SIZE 256
#define BILLING_USERID_MAX_SIZE 32

using namespace ae::stagecraft;

typedef struct BILLING_PURCHASE_INFO
{
	UINT32 result;
	UINT32 errCode;
	char chargeNo[BILLING_CHARGENO_MAX_SIZE];
	char pResult[BILLING_RESPONSEENCDATA_MAX_SIZE];
}BILLING_PURCHASE_INFO_T;

typedef struct BILLING_USER_INFO
{
	char userID[BILLING_USERID_MAX_SIZE];
	UINT32 result;
	UINT32 errCode;
}BILLING_USER_INFO_T;

class Service
{
public :
	Service();
	~Service();

public :
	void billing_purchase(StageWindow *pStageWindow, AEArray<const char*>&arg);	
	void getUserID(StageWindow *pStageWindow, AEArray<const char*>&arg);	
	void requestConfirmUser(StageWindow *pStageWindow, AEArray<const char*>&arg);	
	void requestLogin(StageWindow *pStageWindow, AEArray<const char*>&arg);	
	void getDeviceID(StageWindow *pStageWindow, AEArray<const char*>&arg);
	void setCurrentID(StageWindow *pStageWindow, AEArray<const char*>&arg);	
	void getAppID(StageWindow *pStageWindow, AEArray<const char*>&arg);
};

